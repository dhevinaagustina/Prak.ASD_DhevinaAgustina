package JobsheetGraph.TugasGraph;
import java.util.Scanner;
public class GraphCityMain {
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
    
      // Input jumlah kota
      System.out.print("Input jumlah kota: ");
      int jumlahKota = sc.nextInt();
      sc.nextLine();

      GraphCity graph = new GraphCity(jumlahKota);

      // Input nama kota
      for (int i = 0; i < jumlahKota; i++) {
          System.out.print("Input nama kota: ");
          String namaKota = sc.nextLine();
          graph.addCity(namaKota);
      }

      // Input jumlah jalan
      System.out.print("Input jumlah jalan: ");
      int jumlahJalan = sc.nextInt();
      sc.nextLine();

      for (int i = 0; i < jumlahJalan; i++) {
          System.out.print("Kota 1: ");
          String kota1 = sc.nextLine();
          System.out.print("Kota 2: ");
          String kota2 = sc.nextLine();
          System.out.print("Jarak " + kota1 + " - " + kota2 + ": ");
          int jarak = sc.nextInt();
          sc.nextLine(); 

          graph.addEdge(kota1, kota2, jarak);
      }

      graph.printGraph();
  }

}
    

