package JobsheetGraph.TugasGraph;

public class GraphCity {
    public String[] cities;
    public int[][] adjMatrix;
    public int cityCount;


    // Konstraktor
    public GraphCity(int numOfCities) {
        cities = new String[numOfCities];
        adjMatrix = new int[numOfCities][numOfCities];
        cityCount = 0;
    }

    // Method untuk menambahkan kota
    public void addCity(String city) {
        if (cityCount < cities.length) {
            cities[cityCount++] = city;
        }
    }

    // Method untuk menambahkan edge (jarak) tiap vertex (kota)
    public void addEdge(String city1, String city2, int distance) {
        int index1 = getCityIndex(city1);
        int index2 = getCityIndex(city2);
        if (index1 != -1 && index2 != -1) {
            adjMatrix[index1][index2] = distance;
            adjMatrix[index2][index1] = distance; // Untuk graf tidak berarah
        }
    }

    // Method untuk mencetak isi dalam graph
    public void printGraph() {
        for (int i = 0; i < cityCount; i++) {
            System.out.println(cities[i] + ":");
            for (int j = 0; j < cityCount; j++) {
                if (adjMatrix[i][j] != 0) {
                    System.out.println(" - Jarak ke " + cities[j] + ": " + adjMatrix[i][j]);
                }
            }
        }
    }

    // Metode untuk mendapatkan indeks suatu kota dalam array cities
    public int getCityIndex(String city) {
        for (int i = 0; i < cityCount; i++) {
            if (cities[i].equals(city)) {
                return i;
            }
        }
        return -1; // if city not found (tidak ditemukan)
    }


}
