package Jobsheet9.TugasNo2;
import java.util.Scanner;
public class ScavengerHunt {
    Node head;

    public void addPoint(String question, String answer) {
        Node newNode = new Node(question, answer);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.nextPoint != null) {
                current = current.nextPoint;
            }
            current.nextPoint = newNode;
        }
    }

    public void play() {
        Scanner scanner = new Scanner(System.in);
        Node current = head;
        while (current != null) {
            System.out.println("Pertanyaan: " + current.question);
            System.out.print("Jawaban: ");
            String jawaban = scanner.nextLine().trim().toLowerCase();
            if (jawaban.equals(current.answer.toLowerCase())) {
                System.out.println("Jawaban benar!\n");
                current = current.nextPoint;
            } else {
                System.out.println("Maaf, jawaban Anda salah. Coba lagi.\n");
            }
        }
        scanner.close();
        System.out.println("============================================");
        System.out.println("|   SELAMAT ANDA MENEMUKAN HARTA KARUN!!!  |");
        System.out.println("============================================");

    }


}
