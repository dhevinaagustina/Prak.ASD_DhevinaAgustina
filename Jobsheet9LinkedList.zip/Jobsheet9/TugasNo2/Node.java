package Jobsheet9.TugasNo2;

public class Node {
    String question;
    String answer;
    Node nextPoint;

    public Node(String question, String answer){
        this.question = question;
        this.answer = answer;
        this.nextPoint = null;
    }
}
