package Jobsheet2;

public class PiramidMain {
    public static void main(String[] args) {
        Piramid piramid1 = new Piramid(6, 14,8);
        piramid1.hitungLuasPermukaan();
        piramid1.hitungVolume();
        piramid1.hitungKeliling();
    }
}

